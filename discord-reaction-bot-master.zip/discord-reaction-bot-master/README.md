# discord-reaction-bot
Discord bot which adds reactions to messages
